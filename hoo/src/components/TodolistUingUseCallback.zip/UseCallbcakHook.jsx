import React from 'react'
import { useCallback } from 'react'
import { useState } from 'react'

import TodolistUingUseCallback from './TodolistUingUseCallback'
function UseCallbcakHook() {
    const [todos,setTodos]=useState([])
    let [counter, setcounter] = useState(0)
    const add=()=>{
      setcounter(counter+1)
    }
    const addtodo=  useCallback(()=>{
       return setTodos((prev)=>[...prev, 'new entry']);
    },[]);
        
         
         
       
  return (
    <div>
        
      <TodolistUingUseCallback todos={todos} addtodo={addtodo}/>
      <hr />
      <h1> counter</h1>
    counter: {counter}
    <br />
    <button onClick={add}>addup: {counter} </button>
    <br />
    </div>
  )
}

export default UseCallbcakHook
